var users = [
    {
        name: 'Walter Beans',
        phone: '555-555-1234',
        title: 'manager',
        office: '555-555-5555'
    },
    {
        name: 'Jeff Greene',
        phone: '555-555-2234',
        title: 'developer',
        office: '555-555-6666'
    }
];
