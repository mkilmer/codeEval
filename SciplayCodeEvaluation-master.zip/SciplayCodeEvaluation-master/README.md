# SciplayCodeEvaluation

* Create a directory listing using the users from js/users.js

* From the UI, you should be able to remove, add, and edit users.

* You should provide a way to view the underlying user data structure (ex: console.log).

* Feel free bring in any other libraries/frameworks that you need.

* Explain why you choose the particular libraries/frameworks.
